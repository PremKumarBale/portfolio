// popup.js

const FACT_CHECK_API_KEY = "";   // optional
const CROSS_CHECK_SOURCES = [
  "https://newsapi.org/v2/everything?q=",
];

// API KEY FOR NEWSAPI.ORG (Free tier available)
const NEWS_API_KEY = "227e986ba2b1491ab8bfebef4f2a383d"; // add your key here


function $(id) { return document.getElementById(id); }

function setStatus(msg) {
  $("status").textContent = msg;
}

// extract base domain from URL
function extractDomain(urlString) {
  try {
    let host = new URL(urlString).hostname.toLowerCase();
    if (host.startsWith("www.")) host = host.slice(4);
    return host;
  } catch { return null; }
}

// VERY SHORTENED source lookup table (you can expand)
const KNOWN_SOURCES = {
  "nytimes.com": { politicalLabel: "Lean Left", reliabilityNumeric: 85 },
  "cnn.com": { politicalLabel: "Lean Left", reliabilityNumeric: 78 },
  "foxnews.com": { politicalLabel: "Right", reliabilityNumeric: 45 },
  "bbc.com": { politicalLabel: "Center", reliabilityNumeric: 90 },
  "reuters.com": { politicalLabel: "Center", reliabilityNumeric: 95 },
  "apnews.com": { politicalLabel: "Center", reliabilityNumeric: 92 }
};

function lookupSource(domain) {
  return KNOWN_SOURCES[domain] || {
    politicalLabel: "Unknown",
    reliabilityNumeric: 50
  };
}

function reliabilityScore(meta) {
  return meta.reliabilityNumeric ?? 50;
}


// =============== CONTENT SCRAPE ===============

function scrapeArticleForHawkEye() {
  const root = document.querySelector("article") || document.body;
  const txt = root.innerText.replace(/\s+/g, " ").trim();
  const words = txt.split(" ");
  return {
    wordCount: words.length,
    exclamationCount: (txt.match(/!/g) || []).length,
    linkCount: document.querySelectorAll("a").length,
    snippet: txt.slice(0, 1000)
  };
}

function runOnPage(tabId) {
  return chrome.scripting.executeScript({
    target: { tabId },
    func: scrapeArticleForHawkEye
  }).then(res => res[0].result);
}


// =============== CROSS-PUBLISHER FAKE NEWS CHECK ===============

async function crossCheckHeadline(headline) {
  if (!NEWS_API_KEY) {
    return { status: "no_api_key" };
  }

  const url =
    `https://newsapi.org/v2/everything?` +
    `q="${encodeURIComponent(headline)}"&language=en&apiKey=${NEWS_API_KEY}`;

  try {
    const resp = await fetch(url);
    const data = await resp.json();

    if (!data.articles || data.articles.length === 0) {
      return { status: "no_matches" };
    }

    // check if any reputable source covers the same headline
    let reputableMatches = data.articles.filter(a => {
      let domain = extractDomain(a.url);
      return KNOWN_SOURCES[domain] && KNOWN_SOURCES[domain].reliabilityNumeric >= 75;
    });

    if (reputableMatches.length === 0) {
      return { status: "suspicious", message: "No reputable news outlet is reporting this story." };
    }

    return { status: "ok", results: reputableMatches };

  } catch (e) {
    return { status: "error", message: e.toString() };
  }
}


// =============== RENDER ===============

function renderCrossCheck(data) {
  const c = $("cross-check-results");

  if (data.status === "no_api_key") {
    c.textContent = "Cross-check disabled (missing NewsAPI key)";
    return;
  }
  if (data.status === "no_matches") {
    c.innerHTML = `<span style="color:#f87171;">⚠ No major news outlet is reporting this story.</span>`;
    return;
  }
  if (data.status === "suspicious") {
    c.innerHTML = `<span style="color:#f87171;">⚠ Possible Fake News: ${data.message}</span>`;
    return;
  }
  if (data.status === "error") {
    c.textContent = "Cross-check error: " + data.message;
    return;
  }

  let html = `<strong>Also reported by:</strong><ul>`;
  data.results.slice(0, 5).forEach(a => {
    html += `<li><a href="${a.url}" target="_blank">${a.source.name}</a></li>`;
  });
  html += "</ul>";
  c.innerHTML = html;
}


// =============== MAIN ===============

document.addEventListener("DOMContentLoaded", () => {

  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    const tab = tabs[0];
    const title = tab.title.split("|")[0].split("-")[0].trim();
    $("page-title").textContent = title;

    // Source analysis
    const domain = extractDomain(tab.url);
    const meta = lookupSource(domain);
    $("domain").textContent = domain;
    $("bias-pill").textContent = meta.politicalLabel;
    $("reliability-pill").textContent = meta.reliabilityNumeric >= 80 ? "High" : "Medium";

    // Article analysis
    const analysis = await runOnPage(tab.id);
    $("integrity-score-number").textContent = reliabilityScore(meta);

    // Cross-check for fake news
    const cross = await crossCheckHeadline(title);
    renderCrossCheck(cross);

    setStatus("");
  });

});
